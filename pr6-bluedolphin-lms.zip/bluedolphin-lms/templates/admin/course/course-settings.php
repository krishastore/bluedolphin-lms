<?php
/**
 * Template: Course Settings Metabox.
 *
 * @package BlueDolphin\Lms
 */

?>
<h2>Settings</h2>
