<?php
/**
 * Template: Curriculum Metabox.
 *
 * @package BlueDolphin\Lms
 */

?>
<h2>Curriculum</h2>
