=== BlueDolphin LMS ===
Contributors: krishaweb
Tags: learnpress, lms
Requires at least: 6.0
Tested up to: 6.4.3
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.
