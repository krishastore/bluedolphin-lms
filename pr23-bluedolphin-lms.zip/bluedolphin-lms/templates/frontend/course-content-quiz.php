<?php
/**
 * Template: Course Curriculum - Quiz.
 *
 * @package BlueDolphin\Lms
 *
 * phpcs:disable WordPress.Security.NonceVerification.Recommended
 */
